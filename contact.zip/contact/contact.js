// MODIFICATION : le formulaire prépare maintenant le message pour WhatsApp.
// Le visiteur confirme ensuite lui-même l’envoi dans WhatsApp.

const formulaire = document.querySelector("#form-contact")
const bouton = document.querySelector("#btn-contact")
const listeObjet = document.querySelector("#objet-contact")

// Numéro officiel de la Maison Enrica au format WhatsApp : sans +, espace ou tiret.
const numeroWhatsApp = "243819073170"

// Certains boutons du site indiquent automatiquement le sujet du message.
const parametres = new URLSearchParams(window.location.search)
const objetDemande = parametres.get("objet")

if (objetDemande) {
    const optionExiste = Array.from(listeObjet.options).some((option) => {
        return option.value === objetDemande
    })

    if (optionExiste) {
        listeObjet.value = objetDemande
    }
}

formulaire.addEventListener("submit", (event) => {
    event.preventDefault()

    if (!formulaire.checkValidity()) {
        return
    }

    const nom = document.querySelector("#nom-contact").value.trim()
    const email = document.querySelector("#email-contact").value.trim()
    const objet = listeObjet.value
    const message = document.querySelector("#message-contact").value.trim()

    let texteWhatsApp =
        "Bonjour Maison Enrica," +
        "\n\nNom : " + nom +
        "\nSujet : " + objet

    // L’email est facultatif : il n’est ajouté que si le visiteur l’a renseigné.
    if (email !== "") {
        texteWhatsApp += "\nEmail : " + email
    }

    texteWhatsApp += "\n\nMessage :\n" + message

    const lienWhatsApp =
        "https://wa.me/" +
        numeroWhatsApp +
        "?text=" +
        encodeURIComponent(texteWhatsApp)

    bouton.disabled = true
    bouton.textContent = "Ouverture de WhatsApp..."

    // Ouvre WhatsApp avec le message déjà rempli.
    window.location.href = lienWhatsApp
})

// Réactive le bouton si l’utilisateur revient sur la page.
window.addEventListener("pageshow", () => {
    bouton.disabled = false
    bouton.innerHTML = '<i aria-hidden="true" class="fa-brands fa-whatsapp"></i> Envoyer le message'
})
